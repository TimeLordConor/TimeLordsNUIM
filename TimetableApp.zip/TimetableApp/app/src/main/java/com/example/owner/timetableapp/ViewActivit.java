package com.example.owner.timetableapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class ViewActivit extends AppCompatActivity{

    TextView monday9;
    TextView monday10;
    TextView monday11;
    TextView monday12;
    TextView monday13;
    TextView monday14;
    TextView monday15;
    TextView monday16;
    TextView monday17;

    TextView tuesday9;
    TextView tuesday10;
    TextView tuesday11;
    TextView tuesday12;
    TextView tuesday13;
    TextView tuesday14;
    TextView tuesday15;
    TextView tuesday16;
    TextView tuesday17;

    TextView wednesday9;
    TextView wednesday10;
    TextView wednesday11;
    TextView wednesday12;
    TextView wednesday13;
    TextView wednesday14;
    TextView wednesday15;
    TextView wednesday16;
    TextView wednesday17;

    TextView thursday9;
    TextView thursday10;
    TextView thursday11;
    TextView thursday12;
    TextView thursday13;
    TextView thursday14;
    TextView thursday15;
    TextView thursday16;
    TextView thursday17;

    TextView friday9;
    TextView friday10;
    TextView friday11;
    TextView friday12;
    TextView friday13;
    TextView friday14;
    TextView friday15;
    TextView friday16;
    TextView friday17;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        monday9 = (TextView) findViewById(R.id.mon9);
        monday10 = (TextView) findViewById(R.id.mon10);
    }
}
