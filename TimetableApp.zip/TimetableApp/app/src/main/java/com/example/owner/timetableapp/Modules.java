package com.example.owner.timetableapp;

/**
 * Created by Owner on 20/01/2018.
 */

//Creating object class for Modules
public class Modules {

    String m_ID;
    String m_n;
    String m_v;
    String m_time;
    int m_sem;
    String m_c;
    String m_d;
    int m_y;

    public Modules(){

    }

    public Modules(String moduleID, String modulename, String venue, String time, int semester, String course, String day, int year) {
        this.m_ID = moduleID;
        this.m_n = modulename;
        this.m_v = venue;
        this.m_time = time;
        this.m_sem = semester;
        this.m_c = course;
        this.m_d = day;
        this.m_y = year;

    }

    public String getM_ID(){

        return m_ID;
    }

    public void setM_ID(String id){

        this.m_ID = id;
    }

    public String getM_n() {

        return m_n;
    }

    public void setM_n(String name) {

        this.m_n = name;
    }

    public String getM_v(){

        return m_v;
    }

    public void setM_v(String venue){

        this.m_v = venue;
    }

    public String getM_time(){

        return m_time;
    }

    public void setM_time(String time){

        this.m_time = time;
    }

    public int getM_sem(){

        return m_sem;
    }

    public void setM_sem(int semester){
        this.m_sem = semester;
    }

    public String getM_c(){
        return m_c;
    }

    public void setM_c(String course){
        this.m_c = course;
    }

    public String getM_d(){
        return m_d;
    }

    public void setM_d(String day){
        this.m_d = day;
    }

    public int getM_y(){
        return  m_y;
    }

    public void setM_y(int year){
        this.m_y = year;
    }
}
