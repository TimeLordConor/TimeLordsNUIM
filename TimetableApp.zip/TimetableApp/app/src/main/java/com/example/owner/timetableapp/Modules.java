package com.example.owner.timetableapp;

/**
 * Created by Owner on 20/01/2018.
 */

//Creating object class for Modules
public class Modules {

    String m_ID;
    String m_n;
    String m_v;
    int m_time1;
    int m_time2;
    int m_sem;

    public Modules(){

    }

    public Modules(String moduleID, String modulename, String venue, int time1, int time2, int semester) {
        this.m_ID = moduleID;
        this.m_n = modulename;
        this.m_v = venue;
        this.m_time1 = time1;
        this.m_time2 = time2;
        this.m_sem = semester;

    }

    public String getM_ID(){
        return m_ID;
    }

    public void setM_ID(String id){
        this.m_ID = id;
    }

    public String getM_n() {
        return m_n;
    }

    public void setM_n(String name) {
        this.m_n = name;
    }

    public String getM_v(){
        return m_v;
    }

    public void setM_v(String venue){
        this.m_v = venue;
    }

    public int getM_time1(){
        return m_time1;
    }

    public void setM_time1(int time1){
        this.m_time1 = time1;
    }

    public int getM_time2(){
        return m_time2;
    }

    public void setM_time2(int time2){
        this.m_time2 = time2;
    }

    public int getM_sem(){
        return m_sem;
    }

    public void setM_sem(int semester){
        this.m_sem = semester;
    }
}
