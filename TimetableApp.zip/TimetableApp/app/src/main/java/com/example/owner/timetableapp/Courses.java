package com.example.owner.timetableapp;

/**
 * Created by Owner on 19/01/2018.
 */

//Creating object class for Courses
public class Courses {

    String c_ID;
    String c_n;

    public Courses(){

    }

    public Courses(String courseID, String coursename) {
        this.c_ID = courseID;
        this.c_n = coursename;

    }

    public String getC_ID(){
        return c_ID;
    }

    public void setCourseID(String id){
        this.c_ID = id;
    }

    public String getC_n() {
        return c_n;
    }

    public void setC_n(String name) {
        this.c_n = name;
    }
}
