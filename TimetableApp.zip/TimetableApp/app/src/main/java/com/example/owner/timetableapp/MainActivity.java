package com.example.owner.timetableapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.SharedPreferences;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    SharedPreferences sp;

    public static final String myPref = "MyPrefs";

    SQLiteDatabase ttDb;
    EditText etSem;
    EditText etCourse;
    EditText etYear;
    Button btnRetrieve;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sp = getSharedPreferences(myPref, Context.MODE_PRIVATE);

        ttDb = new SQLiteDatabase(this);

        etSem = (EditText) findViewById(R.id.name_box);
        etCourse = (EditText) findViewById(R.id.course_box);
        etYear = (EditText) findViewById(R.id.year);
        btnRetrieve = (Button) findViewById(R.id.button);

        String c = etCourse.getText().toString();
        String s = etSem.getText().toString();
        String y = etYear.getText().toString();

        SharedPreferences.Editor editor = sp.edit();
        editor.putString("Course", c);
        editor.putString("Semester", c);
        editor.putString("Year",y);
        editor.commit();

        btnRetrieve.setOnClickListener(this);

        //Inserting data for courses into the database
        ttDb.insertCourseData("MH103", "B.Mus Bachelor of Music");
        //Only data for MH103 - Bachelor of Music is inserted for the purpose of demonstration.

        //Inserting data for MH103 Year 1
        ttDb.insertModuleData("MU151", "Music Studies", "RVH", "16:00", 1, "MH103", "Monday", 1);
        ttDb.insertModuleData("MU151", "Music Studies", "CB8", "14:00", 1, "MH103", "Tuesday", 1);
        ttDb.insertModuleData("MU151", "Music Studies", "CB8", "15:00", 1, "MH103", "Tuesday", 1);
        ttDb.insertModuleData("MU153", "Music and Repertoire", "JHL5", "17:00", 1, "MH103", "Monday", 1);
        ttDb.insertModuleData("MU151", "Music and Repertoire", "NMR", "17:00", 1, "MH103", "Thursday", 1);
        ttDb.insertModuleData("MU155", "Creativity and Technique", "BR", "13:00", 1, "MH103", "Monday", 1);
        ttDb.insertModuleData("MU155", "Creativity and Technique", "BR", "13:00", 1, "MH103", "Thursday", 1);
        ttDb.insertModuleData("MU155", "Creativity and Technique", "BR", "13:00", 1, "MH103", "Friday", 1);
        ttDb.insertModuleData("MU152", "Music Studies II", "HF", "16:00", 2, "MH103", "Monday", 1);
        ttDb.insertModuleData("MU154", "Music Traditions and Repertoires II", "BR", "16:00", 2, "MH103", "Wednesday", 1);
        ttDb.insertModuleData("MU154", "Music Traditions and Repertoires II", "BR", "17:00", 2, "MH103", "Wednesday",1 );
        ttDb.insertModuleData("MU156", "Creativity and Technique II", "BR", "13:00", 2, "MH103", "Monday",1 );
        ttDb.insertModuleData("MU156", "Creativity and Technique II", "NMR", "15:00", 2, "MH103", "Tuesday", 1);
        ttDb.insertModuleData("MU156", "Creativity and Technique II", "OCR", "11:00", 2, "MH103", "Friday", 1);

        //Inserting data for MH103 Year 2
        ttDb.insertModuleData("MU208", "Music Textures and Techniques", "OCR", "12:00", 1, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU208", "Music Textures and Techniques", "OCR", "16:00", 1, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU214", "Composition II", "BR", "14:00", 1, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU214", "Composition II", "BR", "15:00", 1, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU262", "Music and Identity", "JHL4", "10:00", 1, "MH103", "Tuesday", 2);
        ttDb.insertModuleData("MU262", "Music and Identity", "CH", "10:00", 1, "MH103", "Friday", 2);
        ttDb.insertModuleData("MU213", "Introduction to Music Technology", "OCR", "14:00", 1, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU213", "Introduction to Music Technology", "OCR", "15:00", 1, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU261", "Music and History", "CB6", "09:00", 1, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU261", "Music and History", "CB7", "11:00", 1, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU253", "Performance II", "BR", "17:00", 1, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU253", "Performance II", "BR", "17:00", 2, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU254", "Ensemble Performance II", "NMR", "12:00", 1, "MH103", "Tuesday", 2);
        ttDb.insertModuleData("MU254", "Ensemble Performance II", "NMR", "12:00", 2, "MH103", "Tuesday", 2);
        ttDb.insertModuleData("MU209", "Advanced Harmony and Harmonic Analysis", "OCR", "12:00", 2, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU209", "Advanced Harmony and Harmonic Analysis", "OCR", "15:00", 2, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU223", "Analytical Methods", "ELT", "14:00", 2, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU223", "Analytical Methods", "RYE", "11:00", 2, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU224", "Electronic Music Composition", "BR", "10:00", 2, "MH103", "Monday", 2);
        ttDb.insertModuleData("MU224", "Electronic Music Composition", "BR", "14:00", 2, "MH103", "Thursday", 2);
        ttDb.insertModuleData("MU226", "Music and Film", "JHL7", "16:00", 2, "MH103", "Tuesday", 2);
        ttDb.insertModuleData("MU226", "Music and Film", "JHL7", "17:00", 2, "MH103", "Tuesday", 2);
        ttDb.insertModuleData("MU264", "Music and Meaning in Contemporary Western Society", "JHL7", "11:00", 2, "MH103", "Tuesday", 2);
        ttDb.insertModuleData("MU264", "Music and Meaning in Contemporary Western Society", "JHL7", "17:00", 2, "MH103", "Thursday", 2);

        //Omitting Year 3 due to time constraints
    }


    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, ViewActivit.class);
        intent.putExtra("Num", etSem.getText().toString());
        intent.putExtra("Course", etCourse.getText().toString());
        intent.putExtra("Year", etYear.getText().toString());

        //Allow passage into ViewActivity once valid (student number and) course code is provided
        if (etSem.length() == 1 && etYear.length() == 1 && etCourse.length() == 5) {
            //Shows toast message for timetable consisting of a specific course
            Toast.makeText(this, "Retrieving semester " + etSem.getText() +" timetable for module " + etCourse.getText() + " in year" + etYear.getText() + ".", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
        else
        {
            //Shows text if invalid information is provided.
            Toast.makeText(this, "ERROR: Missing or invalid details provided. Please re-enter details.", Toast.LENGTH_SHORT).show();
        }
    }
}
