package com.example.owner.timetableapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    SQLiteDatabase ttDb;
    EditText etNum;
    EditText etCourse;
    Button btnRetrieve;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ttDb = new SQLiteDatabase(this);

        etNum = (EditText) findViewById(R.id.name_box);
        etCourse = (EditText) findViewById(R.id.course_box);
        btnRetrieve = (Button) findViewById(R.id.button);

        btnRetrieve.setOnClickListener(this);


    }


    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, ViewActivit.class);
        intent.putExtra("Num", etNum.getText().toString());
        intent.putExtra("Course", etCourse.getText().toString());

        //Allow passage into ViewActivity once valid (student number and) course code is provided
        if (etNum.length() == 8 || etCourse.length() == 5) {
            //Shows toast message for timetable consisting of a specific course
            Toast.makeText(this, "Retrieving timetable for " + etCourse.getText() + ".", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
        else
        {
            //Shows text if invalid information is provided.
            Toast.makeText(this, "ERROR: Missing or invalid details provided. Please re-enter details.", Toast.LENGTH_SHORT).show();
        }
    }
}
