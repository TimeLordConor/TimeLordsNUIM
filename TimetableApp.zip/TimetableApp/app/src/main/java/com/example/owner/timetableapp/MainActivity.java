package com.example.owner.timetableapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText etNum;
    EditText etPass;
    Button btnRetrieve;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum = (EditText) findViewById(R.id.name_box);
        etPass = (EditText) findViewById(R.id.password_box);
        btnRetrieve = (Button) findViewById(R.id.button);

        btnRetrieve.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, ViewActivit.class);
        intent.putExtra("Num", etNum.getText().toString());
        intent.putExtra("Pass", etPass.getText().toString());
        Toast.makeText(this, "The button works at least", Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }
}
