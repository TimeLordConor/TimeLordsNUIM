package com.example.owner.timetableapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;

import java.sql.Time;
import java.util.Date;

/**
 * Created by Owner on 18/01/2018.
 */

public class SQLiteDatabase extends SQLiteOpenHelper{

    //Defining database version
    private static final int DATABASE_VERSION = 1;

    //Defining name of the database
    private static final String DATABASE_NAME = "Timetable";

    //Name of the first table, and its columns, and data types
    private static final String TABLE_NAME1 = "Courses";
    private static final String colc_1 = "course_id";
    private static final String colc_2 = "course_name";

    //As before, for the second table, including time values
    private static final String TABLE_NAME2 = "Modules";
    private static final String colm_1 = "module_id";
    private static final String colm_2 = "module_name";
    private static final String colm_3 = "module_venue";
    private static final String colm_4 = "module_time1";
    private static final String colm_5 = "module_time2";
    private static final String colm_6 = "module_semester";

    //As before, for the relational table
    private static final String TABLE_NAME3 = "is_in";
    private static final String coli_1 = "c_id";
    private static final String coli_2 = "m_id";

    public SQLiteDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(android.database.sqlite.SQLiteDatabase sqLiteDatabase) {
        //Creating the three tables Courses, Modules and is_in)
        String CREATE_COURSE_TABLE = "CREATE TABLE" + TABLE_NAME1 + "("+colc_1+"VARCHAR(6) PRIMARY KEY,"+colc_2+"TEXT"+")";
        sqLiteDatabase.execSQL(CREATE_COURSE_TABLE);
        String CREATE_MODULE_TABLE = "CREATE TABLE" + TABLE_NAME2 + "("+colm_1+"VARCHAR(6) PRIMARY KEY,"+colm_2+"TEXT"+colm_3+"TEXT"+colm_4+
                "INTEGER"+colm_5+"INTEGER"+colm_6+"INTEGER"+")";
        sqLiteDatabase.execSQL(CREATE_MODULE_TABLE);
        String CREATE_RELATIONAL_TABLE = "CREATE TABLE" + TABLE_NAME3 + "("+coli_1+"VARCHAR(6) PRIMARY KEY,"+coli_2+"TEXT"+")";
        sqLiteDatabase.execSQL(CREATE_RELATIONAL_TABLE);
    }

    @Override
    public void onUpgrade(android.database.sqlite.SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //Drop older tables, if in any case they exist
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME1);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME2);
        sqLiteDatabase.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME3);

        //Recreate the tables
        onCreate(sqLiteDatabase);
    }

    public boolean insertCourseData(String courseid, String coursename) {
        android.database.sqlite.SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(colc_1, courseid);
        contentValues.put(colc_2, coursename);
        long result = sqLiteDatabase.insert(TABLE_NAME1, null, contentValues);
        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }
}
